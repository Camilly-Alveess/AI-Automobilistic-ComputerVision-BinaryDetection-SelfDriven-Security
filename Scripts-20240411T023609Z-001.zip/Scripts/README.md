# Ordem Sequencial 


1. Data_Preprocessing

2. Traning_Detection

3. Distance_Detection_Tracking